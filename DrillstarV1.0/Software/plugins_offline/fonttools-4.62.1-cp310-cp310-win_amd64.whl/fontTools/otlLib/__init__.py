"""OpenType Layout-related functionality."""
